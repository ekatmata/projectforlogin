Steps To start project
1.install node.js
2.npm install
2.npm start