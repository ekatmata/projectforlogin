require('dotenv').config()

const ldapjs = require('ldapjs');
const jwt = require('jsonwebtoken');


 const User =  require('../../model/user')
 const logger = require('../../logger');

let refreshTokens = [] ;

module.exports = function (router) {

    // GET : Simple get request to test 

    router.get('/simpleget' , (req , res) => {
        logger.info(" Simple Get request ")
        res.json({message: 'From the get request '})
    });

	// POST : Login Request 
	router.post('/login', function (req, res) { 
        console.log(req.body);
       const  {username,password}=req.body;
       let user={};
       user.username=username;
       user.password=password;
       let userlo=req.body.username;
     
       let userModel={}
       User.findOne({ userlo }).then(
        user => {
            if (user == null) {
                userModel  =new User({username:req.body.username,password:req.body.password});
                console.log("userModel",userModel);
                userModel.save().then(
                    () => {
                        logger.info("New User saved to DB " + JSON.stringify(userModel));
                    })
            }
            else{
                const userEntity = user.toObject();
                const userVo = { 
                 
                    username: userEntity.username,
                   password:userEntity.password
                }
                 resolve(userVo);
            }
           
        })
       const acessToken = jwt.sign(user,'' +process.env.ACCESS_TOKEN_SECRET);  
     
   
      res.json({accessToken:acessToken,users:userModel})
	})

    //  GET:: Test API 
    router.get("/test" ,   (req , res) => {  

        console.log("Request access by " , req.user.username);
        res.json(`Request accessed by ${req.user.username}`)
    })

 
}

