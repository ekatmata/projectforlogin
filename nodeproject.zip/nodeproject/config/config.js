

module.exports = { 
    ldapUrl : "LDAP://iuserldap.nat.bt.com",
    ldapdomain : "OU=employee,OU=btplc,DC=iuser,DC=iroot,DC=adidom,DC=com",
    database: 'mongodb+srv://cluster0.k5pvj.mongodb.net/myFirstDatabase',
    port: 8080,
    host: 'localhost',
    "ldapdomain" :  "OU=employee,OU=btplc,DC=iuser,DC=iroot,DC=adidom,DC=com",
    "ACCESS_TOKEN_SECRET": "241773ef911783fc2f4b5eed0c858445da1f28244f12cc7fdba618fcaa332adbe59708bc5183e2b66f5cba17c2835ee3d823bdf485d69fdd8f2ed76a2c0fc752",
    "REFRESH_TOKEN_SECRET" : "2a6b26d4115e0461134478e5ce188374a15cdd9be993e4590e4c0ee65c87e132460fda0f2a21f8e24dd84282309ba53689be132d9782802114235b89fc125e17"

}

// mongodb+srv://cluster0.k5pvj.mongodb.net/myFirstDatabase
