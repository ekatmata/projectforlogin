require('dotenv').config()
const authentication  = require('./authentication')
const express =  require('express')
const ldapjs = require('ldapjs');
const jwt = require('jsonwebtoken')
const connectDB=require('./app')
const cors = require('cors');
const app = express()
const logger = require('./logger');





app.use(express.json());

const api = require('./api');

const { bootstrapApp } = require('./authentication');

app.use(cors())


// Connecting to mongodb 
connectDB();
app.use('/api',require('./api'))


/* mongoose.connect(mongodb , { useNewUrlParser: true})
const db = mongoose.connection;

db.on('error' , ()=> {
   logger.error(" Error occured while obtaining the db connection : {} ");
})

db.once('open' , () => {
    app.listen(config.port , config.host , async  err => {
        if (err) {
         return logger.error(" Error occured while obtaining the db connection : {} " , err);
        }
        logger.info(" App is started at   " , config.host);
        
       })
}) */


bootstrapApp(app).then(message => logger.info(message)).catch(err => logger.error(err))