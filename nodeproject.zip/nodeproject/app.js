const mongoose = require('mongoose');
var url = "mongodb+srv://ekta:ekta@cluster0.k5pvj.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";

const connectDB= async()=>{
   await mongoose.connect(url,{useUnifiedTopology:true});
   console.log('connection is made')
}
module.exports = connectDB;