const mongoose = require('mongoose');
const config   = require('./config/config')
const logger = require('./config/logger');

module.exports = { 
    bootstrapApp
}
function bootstrapApp(app) {
    return new Promise( (resolve , reject) => {
        // const MongoClient = mongoose.MongoClient;
        // const uri = "mongodb+srv://ekatmata:<ekatmata>@cluster0.k5pvj.mongodb.net/Users?retryWrites=true&w=majority";
        // const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
        // client.connect(err => {
        //     var dbo = db.db("Users");
        //     var myobj = { username: "Ekta", password: "Ekta" };
        //     dbo.collection("User").insertOne(myobj, function(err, res) {
        //       if (err) throw err;
        //       console.log("1 document inserted");
        //     })
        //   const collection = client.db("test").collection("User");
        //   console.log(collection);
        //   console.log(mongoClient.isConnected());
        //   // perform actions on the collection object
        //   client.close();
        // });
//         var url = "mongodb+srv://ekta:ekta@cluster0.k5pvj.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";
//         mongoose.connect(url,{useUnifiedTopology:true});
//     console.log("db is connected")
//     const db = mongoose.connection;

// db.on('error' , ()=> {
//    logger.error(" Error occured while obtaining the db connection : {} ");
// })
            app.listen(config.port , config.host , async  err => {
                if (err) {
                    reject({err , message :"Error occured while obtaining the db connection " })
                }
                logger.info(" App is started at   " , config.host);
                resolve('Application is started ')
                
            })
       

    });
}