import React, { useState,useEffect } from 'react';
import { AgGridColumn, AgGridReact } from 'ag-grid-react';

import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';

function Dashboard(props) {
    const [gridApi, setGridApi] = useState(null);
    const [gridColumnApi, setGridColumnApi] = useState(null);

    const [rowData, setRowData] = useState([{
        "name":"User1",
        "image":"abd"
    },
    {
        "name":"User2",
        "image":"abd"
    },
    {
        "name":"User3",
        "image":"abd"
    } ,
    {
        "name":"User4",
        "image":"abd"
    },
    {
        "name":"User5",
        "image":"abd"
    },
    {
        "name":"User6",
        "image":"abd"
    },
    {
        "name":"User7",
        "image":"abd"
    },  {
        "name":"User8",
        "image":"abd"
    },  {
        "name":"User9",
        "image":"abd"
    },
    {
        "name":"User10",
        "image":"abd"
    },
]);
    const [userdata,setuserData]=useState([]);
    const handleClick = () => {
      
        var userdata= [{
            "name":"User1",
            "image":"abd",
            "id":1
        },
        {
            "name":"User2",
            "image":"abd",
            "id":2
        },
        {
            "name":"User3",
            "image":"abd",
            "id":3
        } ,
        {
            "name":"User4",
            "image":"abd",
            "id":4
        },
        {
            "name":"User5",
            "image":"abd",
            "id":5
        },
        {
            "name":"User6",
            "image":"abd",
            "id":6
        },
        {
            "name":"User7",
            "image":"abd",
            "id":7
        },  {
            "name":"User8",
            "image":"abd",
            "id":8
        },  {
            "name":"User9",
            "image":"abd",
            "id":9
        },
        {
            "name":"User10",
            "image":"abd",
            "id":10
        },
    ]
        setuserData(userdata)
        console.log(userdata);
    }
    useEffect(()=>{
        handleClick()
      },[])
    // const getData=()=>{
    //     var userdata=[
    // ]
    // setData(data,userdata)
    // }
  // handle click event of logout button
//   const handleLogout = () => {    
//     props.history.push('/login');
//   }

  return (
      <div>
{/* <div>
<input type="button" onClick={handleLogout} value="Logout" />
</div> */}
      
    {/* <ul>
     
       {userdata.map(item => (
          <li key={item.name}>{item.name}</li>
         
        ))}
   </ul> */}
   <div className="ag-theme-alpine" style={{ height: 400, width: 600 }}>
            <AgGridReact
                rowData={rowData}>
                <AgGridColumn field="id"></AgGridColumn>
                <AgGridColumn field="name"></AgGridColumn>
                <AgGridColumn field="image"></AgGridColumn>
            </AgGridReact>
        </div>
   </div>
  )
   
}

export default Dashboard;