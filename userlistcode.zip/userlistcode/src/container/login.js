import React, { useState,useEffect } from 'react';
import { setUserSession } from '../Utils/Common';
import './login.css';
 
function Login(props) {
  const username = useFormInput('');
  const password = useFormInput('');
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [data,setData]=useState([]);
 
  // handle button click of login form
  const handleLogin = () => {
    var dummydata
    fetch("http://localhost:8080/api/login", {
  "method": "POST",
  "headers": {
   
    "content-type": "application/json",
    "accept": "application/json"
  },
  "body": JSON.stringify({
    username: username.value,
    password:password.value
  })
})
.then(response => response.json())
.then(response => {
  dummydata=response.accessToken
  console.log(dummydata)
})
.catch(err => {
  console.log(err);
  props.history.push('/error');
});
    setData(dummydata)
    setUserSession( dummydata);
    console.log(dummydata);
      console.log(username);
    console.log(data);
    let idx1= data.findIndex(el=> {
        return username.value === el.username;
      });
    let idx2=data.findIndex(el=> {
        return password.value === el.password;
      });
    console.log(idx1);
    if(dummydata !== null || dummydata.length !== 0){
      props.history.push('/dashboard');
    }else{
      
        props.history.push('/error');
    }
  
  }
  const getData=()=>{
    // var dummydata=[{
    //     "username":"foo",
    //     "password":"bar"
    // }]
  
    // fetch('./data.json'
    // ,{
    //   headers : { 
    //     'Content-Type': 'application/json',
    //     'Accept': 'application/json'
    //    }
    // }
    // )
    //   .then(function(response){
    //     console.log(response)
        
    //     return response.json();
    //   })
    //   .then(function(myJson) {
    //     console.log(myJson);
    //     setData(myJson)
    //   });
  }
  useEffect(()=>{
    getData()
  },[])
 
  return (
    <div className="row" >
    <div className="col=md-12 col-lg-12 col-xs-12">
    <div className="main container">
     
    <div className="login-card">
      <div className="login-header">
        <span > Login</span>
      </div>
     
      <div>
        <div className="input-header">UserName</div>
      <div>  <input className="input-class" type="text" {...username} autoComplete="new-password" /></div>
              
      
      </div>
      <div className="input-header" style={{ marginTop: 10 }}>
        Password<br />
        <input className="input-class" type="password" {...password} autoComplete="new-password" />
      </div>
      {error && <><small style={{ color: 'red' }}>{error}</small><br /></>}<br />
      <input type="button" className="sign-button" value={loading ? 'Loading...' : 'Login'} onClick={handleLogin} disabled={loading} /><br />
    </div>
    </div>
    </div>
    </div>
  );
}
 
const useFormInput = initialValue => {
  const [value, setValue] = useState(initialValue);
 
  const handleChange = e => {
    setValue(e.target.value);
  }
  return {
    value,
    onChange: handleChange
  }
}
 
export default Login;